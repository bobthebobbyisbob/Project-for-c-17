var play = 1
var gameState = "play"
var undead = 0

var tower,towerImage
var ghost, ghostImage
var door, doorImage, doorsGroup
var climber, climberImage, climbersGroup

var invisibleBlock, invisibleBlocksGroup

function preload(){
  
  
  towerImage = loadImage("tower.png");
  ghostImage = loadImage("ghost-standing.png")
  doorImage = loadImage("door.png");
  climberImage = loadImage("climber.png");
  

  
  
}


function setup(){
  
createCanvas(600,600);
  
  tower = createSprite(300,300)
  tower.addImage(towerImage)
  tower.velocityY = 1
  
  ghost = createSprite(300,300)
  ghost.addImage(ghostImage);
  
  ghost.scale = 0.4
  
  doorsGroup = new Group();
  
  climbersGroup = new Group();
  
  invisbleBlocksGroup = new Group();
  
 
  
  
  
  
  
  
}

function draw(){
  
  background(0)
  if(gameState === "play"){
    
    if(keyDown("up")){
      
      ghost.velocityY = -6
      
    }
    
    ghost.velocityY = ghost.velocityY + 0.8
    
    
    if(keyDown("right")){
      
      ghost.x = ghost.x + 3
    }
    
    
    
    if(keyDown("left")){
      
      ghost.x = ghost.x - 3
    }
    
    
    
  if(tower.y>400){
    tower.y = 200
  }
  
    
    thedoorsshallcometh();
    
    ghost.collide(climbersGroup)
    
  if(invisbleBlocksGroup.isTouching(ghost) || ghost.y > 600){
    
     tower.destroy();
     ghost.destroy();
    gameState = "undead"
   
    
    
  }
  
    drawSprites();
    
  }
  
  else if (gameState === "undead"){
    
    stroke("red")
    fill("red")
    textSize(30)
    text("Game Over U suck",190,250)
    
    
    
  }
  
  
  
  
  
  
  
  
  
  
   
  
  
}



function thedoorsshallcometh(){
  
  if(frameCount%100 === 0){
    
    door = createSprite(200,-50);
    door.addImage(doorImage);
    door.velocityY = 5;
    doorsGroup.add(door)
    door.lifetime = 610
    door.x= Math.round (random(120,500))
    ghost.depth = door.depth + 1
    
    
    climber = createSprite(200,10);
    climber.addImage(climberImage);
    climber.velocityY = 5;
    climbersGroup.add(climber)
    climber.lifetime = 610
    climber.x= door.x
    
    invisbleBlock = createSprite(200,15)
    invisbleBlock.velocityY = 5
     invisbleBlocksGroup.add(invisbleBlock)
    invisbleBlock.lifetime = 610
    invisbleBlock.x = climber.x
    invisbleBlock.width = climber.width
    invisbleBlock.height = 2
    invisbleBlock.debug = true
    invisbleBlock.visible = false
    
  }
  
  
  
}